package com.pedrocarrillo.expensetracker.interfaces;

/**
 * Created by pedrocarrillo on 3/20/16.
 */
public interface FileGeneratorParser {

    String generateFileContent();

}
